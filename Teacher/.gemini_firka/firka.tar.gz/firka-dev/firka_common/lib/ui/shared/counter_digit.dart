import 'package:flutter/material.dart';

import 'package:firka_common/ui/theme/style.dart';

class CounterDigitWidget extends StatelessWidget {
  final String c;
  final TextStyle? style;

  const CounterDigitWidget(this.c, this.style, {super.key});

  @override
  Widget build(BuildContext context) {
    return Card(
      shadowColor: Colors.transparent,
      color: appStyle.colors.buttonSecondaryFill,
      child: Padding(
        padding: const EdgeInsets.only(left: 8, right: 8, top: 4, bottom: 4),
        child: Text(c, style: style),
      ),
    );
  }
}
